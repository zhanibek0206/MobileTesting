package utils;

import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.android.AndroidDriver;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class AppiumDriver {
    public static AndroidDriver getAndroidDriver() {
        try {
            AndroidDriver androidDriver;

            DesiredCapabilities desiredCapabilities = new DesiredCapabilities();

            desiredCapabilities.setCapability("noReset", true);
            desiredCapabilities.setCapability("deviceName", "emulator-5554");
            desiredCapabilities.setCapability("platformName", "Android");
            desiredCapabilities.setCapability("appPackage", "kz.kkb.homebank.dev");
            desiredCapabilities.setCapability("appActivity", "kz.beemobile.homebank.ui.splash.SplashActivity");
            desiredCapabilities.setCapability("automationName", "uiautomator2");
            desiredCapabilities.setCapability("app", "C:\\Users\\00054412\\Desktop\\HomeBankTest\\app-qa-debug.apk");
            URL appiumServer = new URL("http://localhost:4723/wd/hub");

            androidDriver = new AndroidDriver(appiumServer, desiredCapabilities);
            androidDriver.manage().timeouts().implicitlyWait(30L, TimeUnit.SECONDS);

            return androidDriver;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
