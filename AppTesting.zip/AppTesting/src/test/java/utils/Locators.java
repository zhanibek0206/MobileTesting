package utils;

public class Locators {

    public static final String SKIP_BUTTON_PATH = "//android.widget.Button[@text='Пропустить']";
    public static final String LOGIN_ICON_XPATH = "kz.kkb.homebank.dev:id/loginImageView";
    public static final String  etLogin = "kz.kkb.homebank.dev:id/etLogin";

    public static final String NEXT_ICON_XPATH = "//android.widget.Button[@text='Далее']";

    public static final String etPassword = "//android.widget.EditText[@text='Пароль']";

    public static final String Account_Login_XPATH = "kz.kkb.homebank.dev:id/btnLogin";

    public static final String CREATE_OTP_XPATH = "kz.kkb.homebank.dev:id/one";

    public static final String CANCEL_ICON_XPATH = "//android.widget.ImageButton[@index='0']";

    public static final String FORGOT_PASSCODE_ICON = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/" +
            "android.widget.FrameLayout/android.widget.FrameLayout/" +
            "android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/" +
            "android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.Button";

    public static final String PHONE_NUMBER_REGISTRATION = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/" +
            "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/" +
            "android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/" +
            "android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.EditText";


    public static final String REG_NEXT_BUTTON = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/" +
            "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/" +
            "android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.Button";

    public static final String BIRTH_DATE_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/" +
            "android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/" +
            "android.widget.LinearLayout/" +
            "android.widget.LinearLayout/android.widget.FrameLayout/android.widget.EditText";
    public static final String NEXT_BUTTON_REGISTRATION = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/" +
            "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/" +
            "android.widget.FrameLayout/android.view.ViewGroup/android.widget.Button";

    public static final String NEXT_TRUST_DEVICE = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/" +
            "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/" +
            "android.widget.FrameLayout/android.view.ViewGroup/android.widget.Button";

    public static final String TRANSFER_BUTTON = "//android.widget.FrameLayout[@index='2']";

    public static final String inputOTP_XPATH = "//android.widget.TextView[@text='1']";

    public static final String anyBankCard = "//android.widget.TextView[@text='На карту']";

    public static final String CLOSE_ICON = "//android.widget.ImageView[@resource-id='kz.kkb.homebank.dev:id/apCloseButton']";

    public static final String EXPAND_ICON_PATH = "//android.widget.ImageView[@index='3']";

    public static final String CHOOSE_CARD_ICON = "//android.widget.TextView[@text='•••• 6114']";

    public static final String LIST_CARDS = "//android.widget.ImageView[@index='2']";

    public static final String CHOOSE_CARD = "//android.widget.TextView[@index='3' and @text='• 5979']";

    public static final String CHOOSE_SUM = "//android.widget.EditText[@text='Сумма перевода']";

    public static final String CONFIRM_BUTTON = "//android.widget.Button[@text='Подтвердить']";

    public static final String BETWEEN_ACCOUNTS = "//android.widget.TextView[@text='Между своими счетами']";

    public static final String SHOW_LIST_CARDS = "//android.widget.TextView[@index='0' and @text='Выберите счет, карту, депозит']";

    public static final String CHOOSE_ACCOUNT = "//android.widget.TextView[@index='0' and @text='Кошелек']";

    public static final String ALL_TRANSFERS_CLICK = "//android.widget.TextView[@index='0' and @text = 'Все переводы']";

    public static final String BY_PHONE_NUMBER_TRANSFER = "//android.widget.TextView[@index='0' and @text='По номеру телефона']";

    public static final String CHOOSE_PHONE_NUMBER_TRANSFER = "//android.widget.EditText[@index='0']";

    public static final String CLICK_ACCOUNTS = "//android.view.View[@index='1']";

    public static final String CHOOSE_ACCOUNT_TRANSFER = "//android.widget.TextView[@index='0' and @text='testreceivername']";
    public static final String COMMENT_MESSAGE = "//android.widget.EditText[@index='0' and @text='Сообщение получателю']";


}
