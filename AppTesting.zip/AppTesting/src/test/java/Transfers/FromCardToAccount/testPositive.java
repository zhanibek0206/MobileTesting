package Transfers.FromCardToAccount;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import utils.AppiumDriver;
import utils.Locators;

import java.time.Duration;

public class testPositive {
    private AndroidDriver androidDriver;

    @Before
    public void setup() {
        // Launch Appium Driver
        androidDriver = AppiumDriver.getAndroidDriver();
    }

    @After
    public void tearDown() {
        // Close the Appium Driver after test execution
        androidDriver.quit();
    }

    @Test
    @Description("Переввод с карты на счёт(Positive)")
    public void testFromCardToAccountPositive() {
        clickTransfer();
        inputOTP("1111");
        clickCloseButton();
        clickBetweenAccounts();
        fromCard();
        toAccount();
        scrollDown();
    }

    @Step("Нажать на кнопку 'Переводы'")
    private void clickTransfer() {
        WebElement clickTransfer = androidDriver.findElement(By.xpath(Locators.TRANSFER_BUTTON));
        clickTransfer.click();
    }

    @Step("Ввести код-пароль")
    private void inputOTP(String otpCode) {
        WebElement otp = androidDriver.findElement(By.xpath(Locators.inputOTP_XPATH));
        for (int i = 0; i < otpCode.length(); i++) {
            otp.click();
        }
    }

    @Step("Закрыть окно")
    private void clickCloseButton() {
        WebElement clickClose = androidDriver.findElement(By.xpath(Locators.CLOSE_ICON));
        clickClose.click();
    }

    @Step("Нажать на 'Между своими счетами'")
    private void clickBetweenAccounts() {
        WebElement betweenAccounts = androidDriver.findElement(By.xpath(Locators.BETWEEN_ACCOUNTS));
        betweenAccounts.click();
    }

    @Step("Выбрать карту, откуда будет совершён перевод")
    private void fromCard() {

        // Показать список карт
        WebElement clickFromCard = androidDriver.findElement(By.xpath(Locators.SHOW_LIST_CARDS));
        clickFromCard.click();

        // Выбор карты
        WebElement chooseCard = androidDriver.findElement(By.xpath(Locators.CHOOSE_CARD_ICON));
        chooseCard.click();

    }

    @Step("Выбор счёта, куда будет переведены деньги")
    private void toAccount() {

        // Показать список карт
        WebElement clickFromCard = androidDriver.findElement(By.xpath(Locators.SHOW_LIST_CARDS));
        clickFromCard.click();

    }

    @Step("Прокрутка экрана вниз")
    private void scrollDown() {

        // Получить размер мобильного утройства
        Dimension windowSize = androidDriver.manage().window().getSize();
        int screenHeight = windowSize.getHeight();
        int screenWidth = windowSize.getWidth();
        System.out.println(screenHeight + " " + screenWidth);

        // Sleep for 10 seconds
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Задание начальных и конечных координат
        int startX = 50 * screenWidth / 100;
        int endX = startX;
        int startY = 90 * screenHeight / 100;
        int endY = 10 * screenHeight / 100;
        System.out.println(startX + " " + startY);
        System.out.println(endX + " " + endY);

        // Прокпутить экран вниз
        PointOption startPoint = new PointOption().withCoordinates(startX, startY);
        PointOption endPoint = new PointOption().withCoordinates(endX, endY);

        TouchAction touchAction = new TouchAction(androidDriver);
        touchAction
                .press(startPoint)
                .waitAction(new WaitOptions().withDuration(Duration.ofSeconds(1)))
                .moveTo(endPoint)
                .release()
                .perform();
    }
}
