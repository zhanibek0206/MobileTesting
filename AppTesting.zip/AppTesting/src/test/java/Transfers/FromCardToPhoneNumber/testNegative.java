package Transfers.FromCardToPhoneNumber;

import io.appium.java_client.android.AndroidDriver;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import utils.AppiumDriver;
import utils.Locators;

import java.io.File;
import java.io.IOException;

public class testNegative {
    private AndroidDriver androidDriver;

    @Before
    public void setup() {
        // Launch Appium Driver
        androidDriver = AppiumDriver.getAndroidDriver();
    }

    @After
    public void tearDown() {
        // Close the Appium Driver after test execution
        androidDriver.quit();
    }

    @Test
    @Description("Перевод с карты на любой мобильный номер (Negative)")
    public void testFromCardToPhoneNegative() throws IOException {
        clickTransfer();
        inputOTP("1111");
        clickCloseButton();
        AllTransfers();
        byPhoneNumberTransfer();
        inputPhoneNumber();
        chooseSum();
        commentMessage();
        clickNextButton();
        String screenshotPath = "C:/Users/00054412/IdeaProjects/AppTesting/src/test/" +
                "java/Transfers/FromCardToPhoneNumber/Screenshots";
        takeScreenshot("LastStep", screenshotPath);
    }
    @Step("Нажать на кнопку 'Переводы'")
    private void clickTransfer() {
        WebElement clickTransfer = androidDriver.findElement(By.xpath(Locators.TRANSFER_BUTTON));
        clickTransfer.click();
    }

    @Step("Ввести код-пароль")
    private void inputOTP(String otpCode) {
        WebElement otp = androidDriver.findElement(By.xpath(Locators.inputOTP_XPATH));
        for (int i = 0; i < otpCode.length(); i++) {
            otp.click();
        }
    }

    @Step("Закрыть окно")
    private void clickCloseButton() {
        WebElement clickClose = androidDriver.findElement(By.xpath(Locators.CLOSE_ICON));
        clickClose.click();
    }

    @Step("Нажать на 'Все переводы'")
    private void AllTransfers() {
        WebElement clickAllTransfers = androidDriver.findElement(By.xpath(Locators.ALL_TRANSFERS_CLICK));
        clickAllTransfers.click();
    }

    @Step("Нажать на 'Перевод по номеру телефона'")
    private void byPhoneNumberTransfer() {
        WebElement clickByPhoneNumber = androidDriver.findElement(By.xpath(Locators.BY_PHONE_NUMBER_TRANSFER));
        clickByPhoneNumber.click();
    }

    @Step("Ввести несуществующий номер телефона")
    private void inputPhoneNumber() {
        WebElement clickPhone = androidDriver.findElement(By.xpath(Locators.CHOOSE_PHONE_NUMBER_TRANSFER));
        clickPhone.click();
        clickPhone.sendKeys("77050000000");
    }

    @Step("Ввести сумму, превыщающую остаток на счёте")
    private void chooseSum() {
        WebElement chooseSum = androidDriver.findElement(By.xpath(Locators.CHOOSE_SUM));
        chooseSum.click();
        chooseSum.sendKeys("10000");
    }

    @Step("Комментарий к переводу")
    private void commentMessage() {
        WebElement clickComment = androidDriver.findElement(By.xpath(Locators.COMMENT_MESSAGE));
        clickComment.click();
        clickComment.sendKeys("Проверка некорректности");
    }

    @Step("Нажимаем на кнопку 'Далее'")
    private void clickNextButton() {
        WebElement nextButton = androidDriver.findElement(By.xpath(Locators.NEXT_ICON_XPATH));
        nextButton.click();

        // Sleep for 10 seconds
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Step("Создание сскриншота")
    private void takeScreenshot(String stepName, String path) {

        // Захват скриншота
        TakesScreenshot screenshot = (TakesScreenshot) androidDriver;
        File screenshotFile = screenshot.getScreenshotAs(OutputType.FILE);


        // Определить путь, где будет сохранён скриншот
        String screenshotFileName = stepName + "_" + System.currentTimeMillis() + ".png";
        String destinationPath = path + File.separator + screenshotFileName;

        // Сохранение скриншота по указанному пути
        try {
            FileUtils.copyFile(screenshotFile, new File(destinationPath));
            System.out.println("Скриншот сохранён по пути " + destinationPath);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Ошибка при сохранении " +
                    "скриншота " + e.getMessage());
        }

    }
}

